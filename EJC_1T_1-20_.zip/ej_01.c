#include <stdlib.h>
#include <stdio.h>

int main()

{
    printf("Dame un numero\n");
    
    int a;
    
    scanf("%d",&a);
    getchar();
    
    printf("Dame otro numero\n");
    
    int b;
    
    scanf("%d",&b);
    getchar();
    
    printf("El producto es: %d",a*b);
    getchar();
    
    return 0;



}