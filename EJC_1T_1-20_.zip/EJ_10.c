//10. Write a program that asks for 2 angles of a triangle and find the third angle.

#include <stdio.h>

int main ()
{
        //Usamos float para aceptar decimales
        float a1, a2, a3;
               
        //Creamos bucles para evitar valores erroneos
        //Bucle en caso de que los dos angulos sumen 180 grados
        do{
            //Bucle del angulo 1
            do
            {
                    printf ("Dime un angulo del triangulo: \n");        
                    scanf ("%f", &a1);
                    getchar ();                    
                    if(a1 > 180 || a1 <0)
                    {
                        printf ("El valor introducido es mayor a 180 o menor que 0, dime otro valor mayor a 0 y menor que 180: \n");
                    }
            } while (a1 > 180 || a1 < 0);
            
            //Bucle de angulo 2      
            do
            {
                    printf ("Dime otro angulo del triangulo: \n");        
                    scanf ("%f", &a2);
                    getchar ();                    
                    if(a2 > 180 || a2 <0)
                    {
                        printf ("El valor introducido es mayor a 180 o menor que 0, dime otro valor mayor a 0 y menor que 180: \n");
                    }
            } while (a2 > 180 || a2 < 0);
            
            //Aviso si los dos angulos introducidos suman más de 180 grados
            if (180 <= a2 + a1)
            {
                    printf ("Los valores introducidos suman 180 o mas\nVuelve a introducir otros valores validos\n");                
            }
        } while (180 <= a2 + a1);
        
        //Operación del tercer ángulo
        a3 = 180 - a1 - a2;
        
        printf ("El valor del tercer angulo es: %f\n",a3);
        
        getchar();
        
        return 0;
}