//09. Write a program that asks for seconds and convert it into minutes, hours and days

#include <stdio.h>

int main ()
{
        //Usamos float para aceptar decimales
        float s, m, h, d;
         
        //Creamos un bucle para evitar valores menores a 0
        do
        {
        printf ("Dime los segundos que quieres convertir: \n");
        scanf ("%f", &s);
        getchar();
        
        if (s<0)
        {
            printf ("El valor es menor a 0, dime otro numero menor a 0\n");
        }
        } while (s<0);
        
        //Operaciones para convertir en minutos, horas y dias
        m = s/60;
        h = m/60;
        d = h/24;
        
        printf ("El valor en minutos es: %fm\nEl valor en horas es: %fh\nEl valor en dias es: %fd\n",m,h,d);
        getchar();
        return 0;
}