//16. Write a program that displays the first 100 prime numbers.

#include <stdio.h>

int main ()
{
        //Usamos int porque los numeros primos no llevan decimales
        int div = 0;
        int contador = 0;
        int i;
        
        printf ("Los 100 primeros numeros primos son:");

        //Creamos un bucle que crea numeros
        for (int j = 2; contador < 100; j++)
        {
            div = 0;
            i = 2;
            
            //Bucle para comprovar que los numeros son primos
            while (i <= j && div == 0)
            {
                if (j%i == 0 && j==i)
                {
                   printf ("%i", j);
                   contador++;
                }
                else if (j%i == 0)
                {
                    div = 1;
                }
               i++;
            }
             
        }
        
        getchar ();
        
        return 0;
}