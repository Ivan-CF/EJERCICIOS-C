//15. Write a program that asks for 1 number to the user and show its binary equivalent value. You can show the binary in inverted order.

#include <stdio.h>

int main ()
{
        //Usamos int para solo aceptar numeros enteros
        int divisor;
        int resto;
        int entrada;
        
        //Creamos el bucle de entrada
        do{
        printf ("Dime el numero que quieras convertir en binario: \n");        
        scanf ("%i", &entrada);
        getchar ();
        
        if (entrada < 0)
            {
                printf ("El valor es menor que 0,dime otro numero mayor que 0\n");
            }
        
        } while (entrada < 0);
        
        printf ("El numero en binario se mostrara ya invertido: ");
        
        //Bucle de calculo del numero en binario
        while (entrada > 0)
        {
            resto = entrada %2;
            entrada /= 2;
            printf ("%d", resto);            
        }
        printf ("\n");     
        
        getchar ();
        
        return 0;
}