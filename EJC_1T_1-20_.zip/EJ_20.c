/*20. Write a calculator program. Program flow should be as follow:
1) Ask for a number (float)
2) Ask for desired operation: '+', '-', '*', '/'
3) Ask for another number (float)
4) Show operation and results
5) Go to step 2) */

#include <stdio.h>
#include <stdlib.h>

int main ()
{
    //Usamos int para solo aceptar enteros
    int num1, num2, resultado, opcion;
    
    //Creamos el bucle
    do
    {
        printf ("Dime un numero: \n");
        scanf ("%i", &num1);
        getchar();
        
        //Creamos un bucle para las operaciones
        do
        {
            printf ("Que quieres hacer: 1=+ 2=- 3=* 4=/ 5=Salir\n");
            scanf ("%i", &opcion);
            getchar();
            
            if (opcion > 5 || opcion <= 0)
            {
                printf ("No es posible, dime otro numero\n");
            }
        } while (opcion > 5 || opcion <= 0);
        
        //Si no se pulsa 5 se pedira segundo
        if (opcion != 5)
        {
            printf ("Dime el segundo numero: \n");
            scanf ("%i", &num2);
            getchar();
        }
        
        //Usamos switch para las operaciones
        switch (opcion)
        {
            case 1: resultado = num1 + num2;
                break;
            case 2: resultado = num1 - num2;
                break;
            case 3: resultado = num1 * num2;
                break;
            case 4: resultado = num1 / num2;
                break;
        }  
        
        //Comprobación final
        if (opcion != 5)
        {
            printf ("El resultado es: %i\n", resultado);
        }
    }while (opcion != 5);
    
   getchar();
   return 0;
}