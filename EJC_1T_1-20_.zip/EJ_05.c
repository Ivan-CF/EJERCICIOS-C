//05. Write a program that asks for radius of a circle and find its diameter, circumference and area.

#include <stdio.h>
#include <stdlib.h>

int main() {
    //Usamos float para aceptar decimales
    float radio, diametro, circunferencia, area;  
   
   //Pedimos el radio y lo guardamos  
    printf("Dime el radio: ");
    scanf("%f", &radio);
    
    getchar();
    
    //Calculos diametro, circunferencia, radio
    diametro = 2 * radio;
    circunferencia = 2 * 3.14 * radio;
    area = 3.14 * (radio * radio);
    
    //Mostramos los resultados
    printf("Diametro del circulo es = %2.f \n", diametro);
    printf("Circunferencia del circulo es = %2.f \n", circunferencia);
    printf("Area del circulo es = %2.f \n", area);
    
    getchar();

    return 0;
}