//06. Write a program that asks for a value in centimeter and convert it into meter and kilometer.

#include <stdio.h>

int main () {

    //Usamos float para aceptar decimales
    float cm, km, m;
            
        
        //Creamos un bucle para evitar valores menores a 0
        do 
        {
            printf ("Dime un valor en centimetros: \n");
            scanf ("%f", &cm);
            getchar();
            if (cm < 0)
            {
                printf ("El valor es menor a 0, dime otro numero mayor a 0 \n");
            }
        } while (cm < 0);
            
        //Operaciones para convertir cm en m y km
        m = cm / 100;
        km = m / 1000;
        
        printf ("El valor en metros es: %fm\nEl valor en kilometros es: %fkm\n",m ,km );
        
        getchar();
       
        return 0;
}