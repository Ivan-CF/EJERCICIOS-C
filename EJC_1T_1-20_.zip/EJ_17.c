//17. Write a program that prints five random numbers, like a Lottery.

#include <stdio.h>
#include <stdlib.h>

int main ()
{
    //Usamos int para solo aceptar numeros enteros
    int numeros = 5;
    
    printf ("Los 5 numeros aleatorios son: ");
    
    //Creamos un bucle para los numeros aleatorios
    for (int i = 0; i<numeros; i++)
    {
        printf ("%d ", rand()%50);
    }
    
   getchar();
   
   return 0;
}