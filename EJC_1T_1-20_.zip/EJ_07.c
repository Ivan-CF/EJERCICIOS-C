//07. Write a program that asks for a temperature in Celsius(°C) and convert it into Fahrenheit(°F).

#include <stdio.h>

int main ()
{
        //Usamos float para aceptar decimales
        float c, f;    
        
        printf ("Dime un valor en grados Celsius: \n");
        scanf ("%f", &c);
        getchar();
        
        //Operacion para convertir en grados Fahrenheit
        f = c*9/5+32;        
        
        printf ("El valor en grados Fahrenheit es: %f\n",f);
       
       getchar();
        
        return 0;
}