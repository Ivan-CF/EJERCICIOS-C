#include <stdio.h>
 
int main ()
{
    int a,b,c;
   
    printf("escribe 1 numero\n");
   
    scanf("%d",&a);
   
    getchar();
   
    printf("escribe otro numero\n");
   
    scanf("%d",&b);
   
    getchar();
   
    printf("escribe otro numero mas porfaplis\n");
   
    scanf("%d",&c);
   
    getchar();
   
    if(a>b)
    {
        if(a>c){
            printf("A es el mayor %d %d %d\n",a,b,c);
        }else if(a<c){
            printf("C es el mayor %d %d %d\n",a,b,c);
        }else{
            printf("A y C son el mayor iguales %d %d %d\n",a,b,c);
        }
    }else if(a<b){
        if(a>c){
            printf("B es el mayor %d %d %d\n",a,b,c);
        }else if(a<c){
            if(b<c){
                printf("C es el mayor %d %d %d\n",a,b,c);
            }else{
                printf("B es el mayor %d %d %d\n",a,b,c);
            }            
        }else{ //a == c
            printf("B es el mayor %d %d %d\n",a,b,c);
        }
    }else if (a == b){
        if(a>c){
            printf("A y B son el mayor %d %d %d\n",a,b,c);
        }else if(a<c){
            printf("C es el mayor %d %d %d\n",a,b,c);        
        }else{ //a == c
            printf("A B y C  son iguales %d %d %d\n",a,b,c);
        }
    }
 
    getchar();
   
    return 0;
 
}