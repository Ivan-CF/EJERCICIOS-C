//12. Write a program that asks for 10 numbers to the user and show the sum and product of all of them. Use while loop.

#include <stdio.h>

int main (){

        //Usamos int para solo aceptar numeros enteros 
        int suma = 0;
        int producto = 1;
        int i = 0;
        int entrada;
        
        //Creamos un bucle con la condición
        while (i<10)
        {
            printf ("Introduce el valor %i de la secuencia de 10 numeros: \n", i+1);        
            scanf ("%i", &entrada);
            getchar ();
            //En cada bucle recalculamos el producto y la suma con el nuevo valor
            producto *= entrada;
            suma += entrada;
            i++;
        }
                
        printf ("La suma total es: %d\nEl producto total es: %d\n",suma, producto);
       
        getchar();
        
        return 0;
}