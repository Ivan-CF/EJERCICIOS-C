//18. Write a function to check if an integer is negative. Function declaration should be: int IsNegative(int num);

#include <stdio.h>

void IsNegative(int num){
        if (num <0){
            printf("El numero %d es negativo.", num);
        }else {
            printf("El numero %d es positivo.", num);
            }
    }
 
int main(){
    int numero = 0;
   
    printf("Introduce un numero: \n");
    scanf("%i", &numero);
    getchar();
   
    IsNegative(numero);    
   
    getchar();
    return 0;
 
}